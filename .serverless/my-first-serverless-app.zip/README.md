# serverless-lamda
Applied serverless with lamda function
